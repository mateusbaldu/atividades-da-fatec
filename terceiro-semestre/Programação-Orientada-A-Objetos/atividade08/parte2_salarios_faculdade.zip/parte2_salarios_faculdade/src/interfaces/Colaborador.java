package interfaces;

public interface Colaborador {
    float valorHora = 50;

    double obtemSalario();
    void cargaHoraria(int cargaHoraria);
}
