package interfaces;

public interface Professor {
    double valorHora = 100;
    String obtemTitulacao();
}
