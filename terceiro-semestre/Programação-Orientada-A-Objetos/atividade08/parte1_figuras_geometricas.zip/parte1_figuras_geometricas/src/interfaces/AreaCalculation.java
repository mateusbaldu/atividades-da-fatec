package interfaces;

public interface AreaCalculation {
    double calculateArea();
}
